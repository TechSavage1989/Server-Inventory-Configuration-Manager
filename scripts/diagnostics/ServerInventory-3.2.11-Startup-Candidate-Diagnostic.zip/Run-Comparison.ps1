﻿# Runs a hash-pinned synthetic helper, never the inventory collector.
$ErrorActionPreference='Stop'
$expected=@{candidate='BFA795D71C8D661C004ADD91E3C6D9E37DACE9A40A2E6433047A2F3CB48079DC'}
foreach($variant in @('candidate')){
 $file=Join-Path $PSScriptRoot ($variant+'.ps1')
 if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $expected[$variant]){Write-Host 'STOP: comparison payload checksum mismatch. Nothing was executed.';exit 2}
}
$exe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess){$exe=Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'}
$log=Join-Path $PSScriptRoot ('Startup-Comparison-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)+'.txt')
[IO.File]::WriteAllText($log,"Synthetic report-helper comparison only. No inventory commands executed.`r`n",(New-Object Text.UTF8Encoding($true)))
foreach($variant in @('candidate')){
 Write-Host ('Running '+$variant+' helper test (maximum 20 seconds).')
 $info=New-Object Diagnostics.ProcessStartInfo
 $info.FileName=$exe
 $info.Arguments='-NoLogo -NoProfile -NonInteractive -File "'+(Join-Path $PSScriptRoot ($variant+'.ps1'))+'"'
 $info.UseShellExecute=$false;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $child=New-Object Diagnostics.Process;$child.StartInfo=$info
 [void]$child.Start()
 $stdout=$child.StandardOutput.ReadToEndAsync();$stderr=$child.StandardError.ReadToEndAsync()
 $finished=$child.WaitForExit(20000)
 if(-not $finished){$child.Kill(); if(-not $child.WaitForExit(2000)){throw "Owned diagnostic child did not exit after termination."}}
 if(-not $stdout.Wait(2000) -or -not $stderr.Wait(2000)){throw "Diagnostic output drain exceeded its deadline."}
 $result="`r`n=== "+$variant+" ===`r`nPayload SHA256: "+$expected[$variant]+"`r`nFinished within timeout: "+$finished+"`r`nChild exit code: "+$child.ExitCode+"`r`n--- Standard output ---`r`n"+$stdout.Result+"--- Error output ---`r`n"+$stderr.Result
 [IO.File]::AppendAllText($log,$result,(New-Object Text.UTF8Encoding($false)))
 $child.Dispose()
}
Write-Host ('Saved '+[IO.Path]::GetFileName($log))
Write-Host 'This is a diagnostic comparison, not an installed application fix.'