SERVER INVENTORY - SYNTHETIC STARTUP COMPARISON

This checks the suspected startup fix; it does not install or update the app.
It includes only seven report-helper functions and made-up values. No server
inventory, role/config/account queries, network calls, exports or admin rights.

1. Extract into a NEW writable folder on the affected Server 2019 computer.
2. Double-click Run-Comparison.cmd normally (not Run as administrator).
3. Wait up to 26 seconds. Only the diagnostic's own child is stopped on timeout.
4. Return Startup-Comparison-*.txt. No automatic upload occurs.

The published negative control uses only a finite collection. The already-known
fatal published cyclic path is deliberately NOT rerun. The candidate runs the
cyclic boundary checks and complete original startup self-tests.
If Windows/PowerShell blocks execution, STOP and report that message. Do not
change execution policy, disable protection, or install another PowerShell.

Logs contain runtime versions, synthetic checkpoint names, child exit codes,
and errors. Errors can include the local diagnostic folder path: redact that
path if desired. No customer inventory or credentials are collected. The only
output is the comparison text file beside the scripts. Delete this extracted
folder when finished.

Published source: collector 3.2.10, SHA256
B072C3CF15F1CEF14DF397718A311A753CFAE0A7B12EBF4380FBED4A2D01C091
The candidate changes only Get-ReportPropertyValue to preserve the property's
object identity at the PowerShell function-output boundary. The supervisor
checks the payload hash before executing it.