@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -File "%~dp0Run-Comparison.ps1"
echo.
echo If script execution was blocked, stop and report the message. Do not change security settings.
pause
